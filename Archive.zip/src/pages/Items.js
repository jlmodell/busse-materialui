import React from "react";

export default function Items() {
  return (
    <div>
      <h1>ITEMS: Busse Hospital Disposables</h1>
    </div>
  );
}

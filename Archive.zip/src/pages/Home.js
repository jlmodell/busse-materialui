import React from "react";

export default function Home() {
  return (
    <div>
      <h1>Busse Hospital Disposables</h1>
    </div>
  );
}
